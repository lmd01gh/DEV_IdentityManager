(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.CustomeprinsaCccObtenerdatosrecuperacionColumnas = new CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper(client, translationProvider);
            this.CustomeprinsaCccPoliticapasswordColumnas = new CustomeprinsaCccPoliticapasswordColumnasWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var CustomeprinsaCccObtenerdatosrecuperacionColumnas = /** @class */ (function (_super) {
        __extends(CustomeprinsaCccObtenerdatosrecuperacionColumnas, _super);
        function CustomeprinsaCccObtenerdatosrecuperacionColumnas() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CCC_SecondaryEmailAddress = _this.GetEntityValue('CCC_SecondaryEmailAddress');
            _this.PhoneMobile = _this.GetEntityValue('PhoneMobile');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        CustomeprinsaCccObtenerdatosrecuperacionColumnas.GetEntitySchema = function () {
            var columns = {
                'CCC_SecondaryEmailAddress': {
                    ColumnName: 'CCC_SecondaryEmailAddress',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PhoneMobile': {
                    ColumnName: 'PhoneMobile',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'Person', Columns: columns };
        };
        return CustomeprinsaCccObtenerdatosrecuperacionColumnas;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the CustomeprinsaCccObtenerdatosrecuperacionColumnas type. */
    var CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive = /** @class */ (function (_super) {
        __extends(CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive, _super);
        function CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive;
    }(CustomeprinsaCccObtenerdatosrecuperacionColumnas));
    var CustomeprinsaCccPoliticapasswordColumnas = /** @class */ (function (_super) {
        __extends(CustomeprinsaCccPoliticapasswordColumnas, _super);
        function CustomeprinsaCccPoliticapasswordColumnas() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.MinLen = _this.GetEntityValue('MinLen');
            _this.MaxLen = _this.GetEntityValue('MaxLen');
            _this.SpecialCharsDenied = _this.GetEntityValue('SpecialCharsDenied');
            _this.HistoryLen = _this.GetEntityValue('HistoryLen');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        CustomeprinsaCccPoliticapasswordColumnas.GetEntitySchema = function () {
            var columns = {
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MinLen': {
                    ColumnName: 'MinLen',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'MaxLen': {
                    ColumnName: 'MaxLen',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'SpecialCharsDenied': {
                    ColumnName: 'SpecialCharsDenied',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'HistoryLen': {
                    ColumnName: 'HistoryLen',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMPwdPolicy', Columns: columns };
        };
        return CustomeprinsaCccPoliticapasswordColumnas;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the CustomeprinsaCccPoliticapasswordColumnas type. */
    var CustomeprinsaCccPoliticapasswordColumnasInteractive = /** @class */ (function (_super) {
        __extends(CustomeprinsaCccPoliticapasswordColumnasInteractive, _super);
        function CustomeprinsaCccPoliticapasswordColumnasInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return CustomeprinsaCccPoliticapasswordColumnasInteractive;
    }(CustomeprinsaCccPoliticapasswordColumnas));
    var CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper = /** @class */ (function () {
        function CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('customeprinsa/ccc/ObtenerDatosRecuperacion/columnas');
        };
        CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('customeprinsa/ccc/ObtenerDatosRecuperacion/columnas');
                this.builder = new imxQbmDbts.TypedEntityBuilder(CustomeprinsaCccObtenerdatosrecuperacionColumnas, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper;
    }());
    var CustomeprinsaCccPoliticapasswordColumnasWrapper = /** @class */ (function () {
        function CustomeprinsaCccPoliticapasswordColumnasWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        CustomeprinsaCccPoliticapasswordColumnasWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('customeprinsa/ccc/PoliticaPassword/columnas');
        };
        CustomeprinsaCccPoliticapasswordColumnasWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('customeprinsa/ccc/PoliticaPassword/columnas');
                this.builder = new imxQbmDbts.TypedEntityBuilder(CustomeprinsaCccPoliticapasswordColumnas, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        CustomeprinsaCccPoliticapasswordColumnasWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.customeprinsa_ccc_PoliticaPassword_columnas_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return CustomeprinsaCccPoliticapasswordColumnasWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.customeprinsa_ccc_CompruebaCaptcha_get = function (Codigo) {
            return {
                path: '/customeprinsa/ccc/CompruebaCaptcha',
                parameters: [
                    {
                        name: 'Codigo',
                        value: Codigo,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get = function (OTP_Login, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/customeprinsa/ccc/ObtenerDatosRecuperacion/columnas',
                parameters: [
                    {
                        name: 'OTP_Login',
                        value: OTP_Login,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.customeprinsa_ccc_PoliticaPassword_columnas_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/customeprinsa/ccc/PoliticaPassword/columnas',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.customeprinsa_ccc_SolicitudOTP_get = function (OTP_Usuario, OTP_EnviarA) {
            return {
                path: '/customeprinsa/ccc/SolicitudOTP',
                parameters: [
                    {
                        name: 'OTP_Usuario',
                        value: OTP_Usuario,
                        in: 'query'
                    },
                    {
                        name: 'OTP_EnviarA',
                        value: OTP_EnviarA,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.customeprinsa_ccc_CompruebaCaptcha_get = function (Codigo, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_CompruebaCaptcha_get(Codigo), requestOptions);
        };
        Client.prototype.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get = function (OTP_Login, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(OTP_Login, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.customeprinsa_ccc_PoliticaPassword_columnas_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_PoliticaPassword_columnas_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.customeprinsa_ccc_SolicitudOTP_get = function (OTP_Usuario, OTP_EnviarA, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_SolicitudOTP_get(OTP_Usuario, OTP_EnviarA), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.customeprinsa_ccc_CompruebaCaptcha_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/customeprinsa/ccc/CompruebaCaptcha',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/customeprinsa/ccc/ObtenerDatosRecuperacion/columnas',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.customeprinsa_ccc_PoliticaPassword_columnas_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/customeprinsa/ccc/PoliticaPassword/columnas',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.customeprinsa_ccc_SolicitudOTP_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/customeprinsa/ccc/SolicitudOTP',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.customeprinsa_ccc_CompruebaCaptcha_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_CompruebaCaptcha_get(options), requestOptions);
        };
        V2Client.prototype.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(options), requestOptions);
        };
        V2Client.prototype.customeprinsa_ccc_PoliticaPassword_columnas_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_PoliticaPassword_columnas_get(options), requestOptions);
        };
        V2Client.prototype.customeprinsa_ccc_SolicitudOTP_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.customeprinsa_ccc_SolicitudOTP_get(options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.CustomeprinsaCccObtenerdatosrecuperacionColumnas = CustomeprinsaCccObtenerdatosrecuperacionColumnas;
    exports.CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive = CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive;
    exports.CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper = CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper;
    exports.CustomeprinsaCccPoliticapasswordColumnas = CustomeprinsaCccPoliticapasswordColumnas;
    exports.CustomeprinsaCccPoliticapasswordColumnasInteractive = CustomeprinsaCccPoliticapasswordColumnasInteractive;
    exports.CustomeprinsaCccPoliticapasswordColumnasWrapper = CustomeprinsaCccPoliticapasswordColumnasWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
