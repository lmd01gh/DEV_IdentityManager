import { ApiClient, ApiRequestOptions, EntityCollectionData, EntitySchema, FilterData, FkProviderItem, IReadValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export declare class TypedClient {
    readonly CustomeprinsaCccObtenerdatosrecuperacionColumnas: CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper;
    readonly CustomeprinsaCccPoliticapasswordColumnas: CustomeprinsaCccPoliticapasswordColumnasWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class CustomeprinsaCccObtenerdatosrecuperacionColumnas extends TypedEntity {
    readonly CCC_SecondaryEmailAddress: IReadValue<string>;
    readonly PhoneMobile: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'CCC_SecondaryEmailAddress' | 'PhoneMobile'>;
}
/** @deprecated Use the CustomeprinsaCccObtenerdatosrecuperacionColumnas type. */
export declare class CustomeprinsaCccObtenerdatosrecuperacionColumnasInteractive extends CustomeprinsaCccObtenerdatosrecuperacionColumnas {
}
export declare class CustomeprinsaCccPoliticapasswordColumnas extends TypedEntity {
    readonly DisplayName: IReadValue<string>;
    readonly MinLen: IReadValue<number>;
    readonly MaxLen: IReadValue<number>;
    readonly SpecialCharsDenied: IReadValue<string>;
    readonly HistoryLen: IReadValue<number>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DisplayName' | 'MinLen' | 'MaxLen' | 'SpecialCharsDenied' | 'HistoryLen'>;
}
/** @deprecated Use the CustomeprinsaCccPoliticapasswordColumnas type. */
export declare class CustomeprinsaCccPoliticapasswordColumnasInteractive extends CustomeprinsaCccPoliticapasswordColumnas {
}
export declare class CustomeprinsaCccObtenerdatosrecuperacionColumnasWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<CustomeprinsaCccObtenerdatosrecuperacionColumnas, unknown>>;
}
export declare class CustomeprinsaCccPoliticapasswordColumnasWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: customeprinsa_ccc_PoliticaPassword_columnas_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<CustomeprinsaCccPoliticapasswordColumnas, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    customeprinsa_ccc_CompruebaCaptcha_get(Codigo: string): MethodDescriptor<string>;
    customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(OTP_Login: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    customeprinsa_ccc_PoliticaPassword_columnas_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    customeprinsa_ccc_SolicitudOTP_get(OTP_Usuario: string, OTP_EnviarA: string): MethodDescriptor<string>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    customeprinsa_ccc_CompruebaCaptcha_get(Codigo: string, requestOptions?: ApiRequestOptions): Promise<string>;
    customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(OTP_Login: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    customeprinsa_ccc_PoliticaPassword_columnas_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    customeprinsa_ccc_SolicitudOTP_get(OTP_Usuario: string, OTP_EnviarA: string, requestOptions?: ApiRequestOptions): Promise<string>;
}
export interface customeprinsa_ccc_CompruebaCaptcha_get_args {
    Codigo?: string;
}
export interface customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get_args {
    OTP_Login?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface customeprinsa_ccc_PoliticaPassword_columnas_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface customeprinsa_ccc_SolicitudOTP_get_args {
    OTP_Usuario?: string;
    OTP_EnviarA?: string;
}
export declare class V2ApiClientMethodFactory {
    customeprinsa_ccc_CompruebaCaptcha_get(options?: customeprinsa_ccc_CompruebaCaptcha_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<string>;
    customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(options?: customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    customeprinsa_ccc_PoliticaPassword_columnas_get(options?: customeprinsa_ccc_PoliticaPassword_columnas_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    customeprinsa_ccc_SolicitudOTP_get(options?: customeprinsa_ccc_SolicitudOTP_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<string>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    customeprinsa_ccc_CompruebaCaptcha_get(options?: customeprinsa_ccc_CompruebaCaptcha_get_args, requestOptions?: ApiRequestOptions): Promise<string>;
    customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get(options?: customeprinsa_ccc_ObtenerDatosRecuperacion_columnas_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    customeprinsa_ccc_PoliticaPassword_columnas_get(options?: customeprinsa_ccc_PoliticaPassword_columnas_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    customeprinsa_ccc_SolicitudOTP_get(options?: customeprinsa_ccc_SolicitudOTP_get_args, requestOptions?: ApiRequestOptions): Promise<string>;
}
